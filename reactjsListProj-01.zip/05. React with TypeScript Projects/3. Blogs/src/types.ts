export interface Blog {
  id: number;
  title: string;
  description: string;
  image: string;
  time: string;
}
