import ComponentA from "./ComponentA";

const App = () => {
  const name = "HuXn";
  return <ComponentA name={name} />;
};

export default App;
