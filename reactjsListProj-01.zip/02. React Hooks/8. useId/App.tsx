import UniqueID from "./components/UniqueID";

const App = () => {
  return (
    <div>
      <UniqueID />
      <p>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Fugit
        consequatur quos quidem cupiditate voluptatem aliquam consequuntur
        excepturi placeat, officia eos commodi et voluptatum beatae quis dicta
        repellat vero maiores nulla.
      </p>
      <UniqueID />
    </div>
  );
};
export default App;
