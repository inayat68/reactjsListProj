import User from "@/live coding/components/User";

export default function Home() {
  return (
    <section>
      {/* <User name="alex" age={20} isStudent={true} /> */}
      <User>
        <p>Hello</p>
      </User>
    </section>
  );
}
