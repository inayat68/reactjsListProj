import Counter from "@/components/Counter";

export default function Home() {
  return (
    <>
      <Counter />
    </>
  );
}
