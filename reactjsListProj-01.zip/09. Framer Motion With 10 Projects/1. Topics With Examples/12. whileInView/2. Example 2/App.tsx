import AnimatedBoxes from "./components/AnimatedGallery";

const App = () => {
  return (
    <div className="mt-[170rem]">
      <AnimatedBoxes />
    </div>
  );
};

export default App;
