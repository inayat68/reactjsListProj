import StaggerAnimation from "./components/Stagger";

const App = () => {
  return (
    <div>
      <StaggerAnimation />
    </div>
  );
};
export default App;
