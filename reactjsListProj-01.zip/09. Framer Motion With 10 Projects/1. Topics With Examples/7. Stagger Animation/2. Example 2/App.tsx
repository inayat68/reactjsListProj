import AnimatedGallery from "./components/AnimatedGallery";

const App = () => {
  return (
    <div>
      <AnimatedGallery />
    </div>
  );
};
export default App;
