import DraggableBox from "./components/DraggableBox";

const App = () => {
  return <DraggableBox />;
};
export default App;
