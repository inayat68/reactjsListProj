import ScrollAnimation from "./components/ScrollAnimation";

const App = () => {
  return (
    <div>
      <ScrollAnimation />
    </div>
  );
};
export default App;
