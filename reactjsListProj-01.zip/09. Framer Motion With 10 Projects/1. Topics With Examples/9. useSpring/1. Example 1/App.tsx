import RangeSlider from "./components/RangeSlider";

const App = () => {
  return <RangeSlider />;
};

export default App;
