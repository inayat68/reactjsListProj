import AnimatedShape from "./components/ExampleOne";

const App = () => {
  return <AnimatedShape />;
};

export default App;
