import ColorChanger from "./components/RangeSlider";

const App = () => {
  return <ColorChanger />;
};
export default App;
