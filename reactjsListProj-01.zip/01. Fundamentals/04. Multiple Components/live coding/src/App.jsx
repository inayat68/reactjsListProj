import Greetings from "./components/Greetings";
import Add from "./components/Add";

const App = () => {
  return (
    <>
      <Greetings />
      <Add />
    </>
  );
};

export default App;
