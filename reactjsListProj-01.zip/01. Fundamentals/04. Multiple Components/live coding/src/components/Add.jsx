const Add = () => {
  return <div>Add</div>;
};

export default Add;
