const Greetings = () => {
  return <div>Greetings</div>;
};

export default Greetings;
