const WelcomeMessage = () => {
  return (
    <div>
      <h1>Hello, World!</h1>
      <p>Welcome to learning JSX!</p>
    </div>
  );
};

export default WelcomeMessage;
