import CopyInput from "./components/CopyInput";

const App = () => {
  return (
    <div>
      <CopyInput />
    </div>
  );
};
export default App;
