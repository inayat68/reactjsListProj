import "./index.css";

const App = () => {
  return (
    <section>
      <h1>Separate File For Styling</h1>
    </section>
  );
};

export default App;
