import ProductList from "./components/ProductList";
import UserList from "./components/UserList";

function App() {
  return (
    <>
      {/* <UserList /> */}
      <ProductList />
    </>
  );
}

export default App;
