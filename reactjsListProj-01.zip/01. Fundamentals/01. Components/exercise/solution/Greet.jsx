// function Greet() {
//   return <h1>Greet</h1>;
// }

const Greet = () => {
  return <h1>Greet</h1>;
};
