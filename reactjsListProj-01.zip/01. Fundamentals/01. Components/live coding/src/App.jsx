// function App() {
//   return <div>Component 🤝</div>;
// }

// export default App;
// --------------------------

// rafce
const App = () => {
  return <div>Component 🤝</div>;
};

export default App;
