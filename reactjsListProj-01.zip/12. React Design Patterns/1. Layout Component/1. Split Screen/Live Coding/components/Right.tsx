const Right = () => {
  return <div className="bg-red-400">Right</div>;
};

export default Right;
