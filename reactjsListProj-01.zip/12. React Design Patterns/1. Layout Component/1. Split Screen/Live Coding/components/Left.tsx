const Left = () => {
  // return <div className="bg-teal-400">Left</div>;
  return <div className="bg-teal-400 h-[46rem]">Left</div>;
};

export default Left;
