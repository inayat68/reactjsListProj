const Footer = () => {
  return (
    <footer className="bg-teal-800 text-white p-4 text-center">
      <p>&copy; 2025 My Dashboard App</p>
    </footer>
  );
};

export default Footer;
