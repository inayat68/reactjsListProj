import UncontrolledForm from "./components/UncontrolledForm";

const App = () => {
  return (
    <div>
      <UncontrolledForm />
    </div>
  );
};

export default App;
