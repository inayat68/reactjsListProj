import ControlledForm from "./components/ControlledForm";

const App = () => {
  return (
    <div>
      <ControlledForm />
    </div>
  );
};

export default App;
