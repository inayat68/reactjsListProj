import Users from "./components/Users";

const App = () => {
  return (
    <div>
      <Users />
    </div>
  );
};
export default App;
