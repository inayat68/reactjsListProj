import MyForm from "./components/MyForm";

const App = () => {
  return (
    <div>
      <MyForm />
    </div>
  );
};

export default App;
