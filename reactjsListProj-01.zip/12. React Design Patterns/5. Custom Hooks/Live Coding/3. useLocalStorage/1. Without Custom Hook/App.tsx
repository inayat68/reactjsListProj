import ThemeToggle from "./components/ThemeToggle";

const App = () => {
  return (
    <div>
      <ThemeToggle />
    </div>
  );
};

export default App;
