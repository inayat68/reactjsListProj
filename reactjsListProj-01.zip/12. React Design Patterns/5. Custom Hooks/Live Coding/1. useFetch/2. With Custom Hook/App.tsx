import WithCustomHook from "./components/WithCustomHook";

const App = () => {
  return (
    <div>
      <WithCustomHook />
    </div>
  );
};

export default App;
