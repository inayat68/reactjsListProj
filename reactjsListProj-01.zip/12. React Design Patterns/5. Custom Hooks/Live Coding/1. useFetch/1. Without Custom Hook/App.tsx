import WithoutCustomHook from "./components/1. WithoutCustomHook";

const App = () => {
  return (
    <div>
      <WithoutCustomHook />
    </div>
  );
};

export default App;
