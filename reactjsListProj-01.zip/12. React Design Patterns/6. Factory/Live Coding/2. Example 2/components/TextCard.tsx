const TextCard = ({ text }: any) => (
  <div className="border p-[10px] m-[10px]">
    <p>{text}</p>
  </div>
);

export default TextCard;
