const NotAuthorized = () => (
  <div>You are not authorized to view this content.</div>
);

export default NotAuthorized;
