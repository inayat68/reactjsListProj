const MyComponent = ({ data }: any) => {
  return <div>{data}</div>;
};

export default MyComponent;
