import { ReactNode } from "react";

const CardTitle = ({ children }: { children: ReactNode }) => {
  return <div>{children}</div>;
};
export default CardTitle;
