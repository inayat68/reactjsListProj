import { ReactNode } from "react";

const CardButton = ({ children }: { children: ReactNode }) => {
  return <div>{children}</div>;
};
export default CardButton;
