import ToggleBackgroundColor from "./ToggleBackgroundColor";

const App = () => {
  return <ToggleBackgroundColor />;
};

export default App;
