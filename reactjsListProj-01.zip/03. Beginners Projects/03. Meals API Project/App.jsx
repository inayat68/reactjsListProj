import Main from "./Main";

const App = () => {
  return <Main />;
};

export default App;
