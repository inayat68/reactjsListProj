import HiddenSearchBar from "./HiddenSearchBar";

const App = () => {
  return <HiddenSearchBar />;
};

export default App;
