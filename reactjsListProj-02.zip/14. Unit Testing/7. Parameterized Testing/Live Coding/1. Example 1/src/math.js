export const multiply = (a, b) => a * b;
