export function reverseString(str) {
  return str.split("").reverse().join("");
}
