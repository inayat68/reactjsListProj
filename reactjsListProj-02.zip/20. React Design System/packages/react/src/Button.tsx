const Button = (props: any) => {
  return (
    <button className="huxn-bg-warning-500 huxn-px-8 huxn-py-4 huxn-rounded-small huxn-font-semibold">
      Click Me
    </button>
  );
};

export default Button;
