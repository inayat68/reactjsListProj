import { add } from "mymath";
console.log(add(2, 3));
