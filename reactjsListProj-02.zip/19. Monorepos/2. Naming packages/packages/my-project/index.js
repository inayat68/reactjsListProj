import { add } from "@huxn/mymath";
console.log(add(2, 3));
