const Button = () => {
  return <button>Click Me</button>;
};

export default Button;
