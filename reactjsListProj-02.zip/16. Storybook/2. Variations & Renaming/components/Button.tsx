const Button = (props) => {
  return <button {...props} />;
};

export default Button;
