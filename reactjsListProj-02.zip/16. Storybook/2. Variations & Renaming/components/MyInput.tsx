const MyInput = (props) => {
  return <input {...props} style={{ width: props.size }} />;
};

export default MyInput;
