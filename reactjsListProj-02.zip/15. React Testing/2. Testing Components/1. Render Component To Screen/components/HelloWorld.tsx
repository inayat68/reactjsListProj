const HelloWorld = () => {
  return <div>HelloWorld</div>;
};

export default HelloWorld;
