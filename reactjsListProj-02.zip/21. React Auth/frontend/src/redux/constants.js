export const BASE_URL = "";
export const USERS_URL = "/api/v1/users";
