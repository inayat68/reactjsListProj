import { View } from "react-native";
import RandomUserComponent from "../components/RandomUser";
import SeafoodMeals from "../components/SeaFoodMeals";

const Index = () => {
  return (
    <View>
      {/* <RandomUserComponent /> */}
      <SeafoodMeals />
    </View>
  );
};

export default Index;
