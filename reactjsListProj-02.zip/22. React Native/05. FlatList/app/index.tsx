import ListData from "./components/ListData";
import ArrayOfObjects from "./components/ArrayOfObjects";
import { View } from "react-native";

const Index = () => {
  return (
    <View>
      {/* <ListData /> */}
      <ArrayOfObjects />
    </View>
  );
};

export default Index;
