import ComponentA from "@/components/ComponentA";
import { View, Text } from "react-native";

const Index = () => {
  const name = "HuXn";

  return <ComponentA username={name} />;
};

export default Index;
