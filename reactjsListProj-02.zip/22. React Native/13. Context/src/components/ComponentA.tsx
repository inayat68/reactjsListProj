import { View, Text } from "react-native";
import ComponentB from "./ComponentB";

const ComponentA = () => {
  return <ComponentB />;
};

export default ComponentA;
