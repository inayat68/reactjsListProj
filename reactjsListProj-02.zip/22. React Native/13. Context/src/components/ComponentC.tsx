import { View, Text } from "react-native";
import ComponentD from "./ComponentD";

const ComponentC = () => {
  return <ComponentD />;
};

export default ComponentC;
