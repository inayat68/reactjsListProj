import { View, Text, StyleSheet } from "react-native";
import ComponentA from "./components/ComponentA";

const Index = () => {
  return (
    <Text>
      Hello
      <ComponentA />
    </Text>
  );
};

export default Index;
