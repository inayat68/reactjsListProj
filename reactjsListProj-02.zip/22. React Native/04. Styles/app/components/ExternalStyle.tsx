import { Text, View } from "react-native";
import st from "./style";

const ExternalStyle = () => {
  return (
    <View>
      <Text style={st.textStyle}>HuXn WebDev</Text>
    </View>
  );
};

export default ExternalStyle;
