import { StyleSheet } from "react-native";

const st = StyleSheet.create({
  textStyle: {
    color: "white",
    fontSize: 30,
    backgroundColor: "teal",
    margin: 20,
    padding: 20,
  },
});

export default st;
