import { View } from "react-native";
import ToDoApp from "../components/Todo";
import ShoppingCartApp from "../components/ShoppingCart";
import UserProfileApp from "../components/UserProfile";

const Index = () => {
  return (
    <View>
      {/* <ToDoApp /> */}
      {/* <UserProfileApp /> */}
      <ShoppingCartApp />
    </View>
  );
};

export default Index;
