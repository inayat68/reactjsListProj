import DynamicContent from "./components/DynamicContent";

const Index = () => {
  return <DynamicContent />;
};

export default Index;
